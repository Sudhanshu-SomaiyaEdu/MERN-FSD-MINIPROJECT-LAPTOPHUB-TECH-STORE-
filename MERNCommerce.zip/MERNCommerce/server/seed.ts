import { storage } from "./storage";
import { hashPassword } from "./utils/auth";

const sampleProducts = [
  {
    name: "Gaming Laptop Pro X15",
    brand: "TechPro",
    category: "Gaming",
    price: "1299.00",
    originalPrice: "1599.00",
    image: "/generated_images/Gaming_laptop_product_shot_413042a2.png",
    processor: "Intel i7-12700H",
    ram: "16GB DDR4",
    storage: "512GB NVMe SSD",
    description: "High-performance gaming laptop with NVIDIA RTX 3060 graphics, 144Hz display, and RGB backlit keyboard. Perfect for gaming and content creation.",
    stock: 15,
    rating: "4.8",
    reviewCount: 142,
  },
  {
    name: "Business Ultrabook Elite",
    brand: "WorkStation",
    category: "Business",
    price: "899.00",
    image: "/generated_images/Business_ultrabook_product_shot_15371343.png",
    processor: "Intel i5-1235U",
    ram: "8GB DDR4",
    storage: "256GB SSD",
    description: "Sleek and professional ultrabook designed for business users. Lightweight, long battery life, and enterprise-grade security features.",
    stock: 22,
    rating: "4.5",
    reviewCount: 89,
  },
  {
    name: "Creator Workstation Max",
    brand: "ProBook",
    category: "Workstation",
    price: "2199.00",
    originalPrice: "2499.00",
    image: "/generated_images/Workstation_laptop_product_shot_795ba6a5.png",
    processor: "Intel i9-12900H",
    ram: "32GB DDR5",
    storage: "1TB NVMe SSD",
    description: "Professional workstation laptop for creators and developers. Powerful performance, stunning 4K display, and professional-grade GPU.",
    stock: 8,
    rating: "4.9",
    reviewCount: 67,
  },
  {
    name: "Portable Laptop Rose",
    brand: "SlimTech",
    category: "Ultrabook",
    price: "749.00",
    image: "/generated_images/Portable_laptop_product_shot_3e086ad4.png",
    processor: "Intel i5-1135G7",
    ram: "8GB LPDDR4",
    storage: "256GB SSD",
    description: "Ultra-portable laptop in elegant rose gold. Perfect for students and travelers who need a lightweight, reliable device.",
    stock: 18,
    rating: "4.4",
    reviewCount: 124,
  },
  {
    name: "Convertible 2-in-1 Pro",
    brand: "FlexBook",
    category: "2-in-1",
    price: "1099.00",
    image: "/generated_images/Convertible_laptop_product_shot_c7aaeac1.png",
    processor: "Intel i7-1255U",
    ram: "16GB LPDDR5",
    storage: "512GB SSD",
    description: "Versatile 2-in-1 laptop with touchscreen and stylus support. Seamlessly switch between laptop and tablet modes for maximum flexibility.",
    stock: 12,
    rating: "4.6",
    reviewCount: 98,
  },
  {
    name: "Gaming Beast RTX 4070",
    brand: "TechPro",
    category: "Gaming",
    price: "1799.00",
    image: "/generated_images/Gaming_laptop_product_shot_413042a2.png",
    processor: "Intel i9-13900HX",
    ram: "32GB DDR5",
    storage: "1TB NVMe SSD",
    description: "Ultimate gaming powerhouse with NVIDIA RTX 4070 graphics, 240Hz display, and advanced cooling system. Dominate any game at maximum settings.",
    stock: 6,
    rating: "5.0",
    reviewCount: 203,
  },
];

export async function seedData() {
  console.log("Seeding data...");

  // Create admin user
  const hashedPassword = await hashPassword("admin123");
  const adminUser = await storage.createUser({
    name: "Admin User",
    email: "admin@test.com",
    password: hashedPassword,
  });

  // Manually set admin status (hack for in-memory storage)
  (adminUser as any).isAdmin = true;

  // Create regular test user
  const testPassword = await hashPassword("password123");
  await storage.createUser({
    name: "John Doe",
    email: "john@example.com",
    password: testPassword,
  });

  console.log("Created users:");
  console.log("  Admin: admin@test.com / admin123");
  console.log("  User: john@example.com / password123");

  // Create products
  for (const product of sampleProducts) {
    await storage.createProduct(product);
  }

  console.log(`Created ${sampleProducts.length} products`);
  console.log("Seeding complete!");
}
