import { Response } from "express";
import asyncHandler from "express-async-handler";
import { storage } from "../storage";
import { AuthRequest } from "../middleware/auth";

export const createOrder = asyncHandler(async (req: AuthRequest, res: Response) => {
  const { orderItems, shippingAddress, paymentMethod, totalPrice } = req.body;

  if (!orderItems || orderItems.length === 0) {
    res.status(400).json({ message: "No order items" });
    return;
  }

  if (!shippingAddress || !paymentMethod || !totalPrice) {
    res.status(400).json({ message: "Missing required fields" });
    return;
  }

  const order = await storage.createOrder({
    userId: req.user!.id,
    shippingAddress: JSON.stringify(shippingAddress),
    paymentMethod,
    totalPrice: totalPrice.toString(),
    isPaid: false,
    isDelivered: false,
    paidAt: null,
    deliveredAt: null,
  });

  for (const item of orderItems) {
    await storage.createOrderItem({
      orderId: order.id,
      productId: item.productId,
      productName: item.productName,
      productPrice: item.productPrice.toString(),
      quantity: item.quantity,
    });
  }

  await storage.clearCart(req.user!.id);

  res.status(201).json(order);
});

export const getOrderById = asyncHandler(async (req: AuthRequest, res: Response) => {
  const order = await storage.getOrder(req.params.id);

  if (!order) {
    res.status(404).json({ message: "Order not found" });
    return;
  }

  if (order.userId !== req.user!.id && !req.user!.isAdmin) {
    res.status(403).json({ message: "Not authorized to view this order" });
    return;
  }

  const orderItems = await storage.getOrderItems(order.id);

  res.json({
    ...order,
    orderItems,
  });
});

export const getUserOrders = asyncHandler(async (req: AuthRequest, res: Response) => {
  const orders = await storage.getUserOrders(req.user!.id);
  res.json(orders);
});

export const getAllOrders = asyncHandler(async (req: AuthRequest, res: Response) => {
  const orders = await storage.getAllOrders();
  res.json(orders);
});

export const updateOrderToPaid = asyncHandler(async (req: AuthRequest, res: Response) => {
  const order = await storage.getOrder(req.params.id);

  if (!order) {
    res.status(404).json({ message: "Order not found" });
    return;
  }

  const updated = await storage.updateOrder(order.id, {
    isPaid: true,
    paidAt: new Date(),
  });

  res.json(updated);
});
