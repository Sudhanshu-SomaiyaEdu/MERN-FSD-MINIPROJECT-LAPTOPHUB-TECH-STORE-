import { Response } from "express";
import asyncHandler from "express-async-handler";
import { storage } from "../storage";
import { AuthRequest } from "../middleware/auth";
import { insertProductSchema } from "@shared/schema";

export const createProduct = asyncHandler(async (req: AuthRequest, res: Response) => {
  const result = insertProductSchema.safeParse(req.body);

  if (!result.success) {
    res.status(400).json({ message: "Invalid input", errors: result.error.errors });
    return;
  }

  const product = await storage.createProduct(result.data);
  res.status(201).json(product);
});

export const updateProduct = asyncHandler(async (req: AuthRequest, res: Response) => {
  const product = await storage.getProductById(req.params.id);

  if (!product) {
    res.status(404).json({ message: "Product not found" });
    return;
  }

  const updated = await storage.updateProduct(req.params.id, req.body);
  res.json(updated);
});

export const deleteProduct = asyncHandler(async (req: AuthRequest, res: Response) => {
  const deleted = await storage.deleteProduct(req.params.id);

  if (!deleted) {
    res.status(404).json({ message: "Product not found" });
    return;
  }

  res.json({ message: "Product deleted" });
});
