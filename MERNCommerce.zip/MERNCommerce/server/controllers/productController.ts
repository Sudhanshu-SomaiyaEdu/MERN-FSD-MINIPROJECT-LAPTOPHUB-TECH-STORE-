import { Request, Response } from "express";
import asyncHandler from "express-async-handler";
import { storage } from "../storage";

export const getProducts = asyncHandler(async (req: Request, res: Response) => {
  const products = await storage.getAllProducts();
  res.json(products);
});

export const getProductById = asyncHandler(async (req: Request, res: Response) => {
  const product = await storage.getProductById(req.params.id);
  
  if (!product) {
    res.status(404).json({ message: "Product not found" });
    return;
  }
  
  res.json(product);
});
