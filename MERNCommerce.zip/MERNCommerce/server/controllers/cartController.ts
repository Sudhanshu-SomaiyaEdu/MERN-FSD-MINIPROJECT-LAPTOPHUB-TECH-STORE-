import { Response } from "express";
import asyncHandler from "express-async-handler";
import { storage } from "../storage";
import { AuthRequest } from "../middleware/auth";
import { insertCartItemSchema } from "@shared/schema";

export const getCartItems = asyncHandler(async (req: AuthRequest, res: Response) => {
  const cartItems = await storage.getCartItems(req.user!.id);
  
  const itemsWithProducts = await Promise.all(
    cartItems.map(async (item) => {
      const product = await storage.getProductById(item.productId);
      return {
        ...item,
        product,
      };
    })
  );

  res.json(itemsWithProducts);
});

export const addCartItem = asyncHandler(async (req: AuthRequest, res: Response) => {
  const { productId, quantity } = req.body;

  if (!productId || !quantity || quantity < 1) {
    res.status(400).json({ message: "Invalid input" });
    return;
  }

  const product = await storage.getProductById(productId);
  if (!product) {
    res.status(404).json({ message: "Product not found" });
    return;
  }

  const existingItem = await storage.getCartItem(req.user!.id, productId);

  if (existingItem) {
    const updated = await storage.updateCartItem(existingItem.id, existingItem.quantity + quantity);
    res.json(updated);
  } else {
    const cartItem = await storage.addCartItem({
      userId: req.user!.id,
      productId,
      quantity,
    });
    res.status(201).json(cartItem);
  }
});

export const updateCartItem = asyncHandler(async (req: AuthRequest, res: Response) => {
  const { quantity } = req.body;

  if (!quantity || quantity < 1) {
    res.status(400).json({ message: "Invalid quantity" });
    return;
  }

  const item = await storage.updateCartItem(req.params.id, quantity);

  if (!item) {
    res.status(404).json({ message: "Cart item not found" });
    return;
  }

  res.json(item);
});

export const removeCartItem = asyncHandler(async (req: AuthRequest, res: Response) => {
  const deleted = await storage.removeCartItem(req.params.id);

  if (!deleted) {
    res.status(404).json({ message: "Cart item not found" });
    return;
  }

  res.json({ message: "Item removed from cart" });
});

export const clearCart = asyncHandler(async (req: AuthRequest, res: Response) => {
  await storage.clearCart(req.user!.id);
  res.json({ message: "Cart cleared" });
});
