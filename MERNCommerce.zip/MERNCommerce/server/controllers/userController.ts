import { Request, Response } from "express";
import asyncHandler from "express-async-handler";
import { storage } from "../storage";
import { hashPassword, comparePassword, generateToken } from "../utils/auth";
import { insertUserSchema } from "@shared/schema";

export const registerUser = asyncHandler(async (req: Request, res: Response) => {
  const result = insertUserSchema.safeParse(req.body);
  
  if (!result.success) {
    res.status(400).json({ message: "Invalid input", errors: result.error.errors });
    return;
  }

  const { name, email, password } = result.data;

  const existingUser = await storage.getUserByEmail(email);
  if (existingUser) {
    res.status(400).json({ message: "User already exists" });
    return;
  }

  const hashedPassword = await hashPassword(password);

  const user = await storage.createUser({
    name,
    email,
    password: hashedPassword,
  });

  const token = generateToken(user.id);

  res.status(201).json({
    id: user.id,
    name: user.name,
    email: user.email,
    isAdmin: user.isAdmin,
    token,
  });
});

export const loginUser = asyncHandler(async (req: Request, res: Response) => {
  const { email, password } = req.body;

  if (!email || !password) {
    res.status(400).json({ message: "Please provide email and password" });
    return;
  }

  const user = await storage.getUserByEmail(email);

  if (!user) {
    res.status(401).json({ message: "Invalid email or password" });
    return;
  }

  const isPasswordValid = await comparePassword(password, user.password);

  if (!isPasswordValid) {
    res.status(401).json({ message: "Invalid email or password" });
    return;
  }

  const token = generateToken(user.id);

  res.json({
    id: user.id,
    name: user.name,
    email: user.email,
    isAdmin: user.isAdmin,
    token,
  });
});

export const getUserProfile = asyncHandler(async (req: any, res: Response) => {
  const user = await storage.getUser(req.user.id);

  if (!user) {
    res.status(404).json({ message: "User not found" });
    return;
  }

  res.json({
    id: user.id,
    name: user.name,
    email: user.email,
    isAdmin: user.isAdmin,
  });
});
