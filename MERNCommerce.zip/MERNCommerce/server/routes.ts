import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import productRoutes from "./routes/productRoutes";
import userRoutes from "./routes/userRoutes";
import cartRoutes from "./routes/cartRoutes";
import orderRoutes from "./routes/orderRoutes";
import adminRoutes from "./routes/adminRoutes";

export async function registerRoutes(app: Express): Promise<Server> {
  // Register API routes
  app.use("/api/products", productRoutes);
  app.use("/api/users", userRoutes);
  app.use("/api/cart", cartRoutes);
  app.use("/api/orders", orderRoutes);
  app.use("/api/admin", adminRoutes);

  const httpServer = createServer(app);

  return httpServer;
}
