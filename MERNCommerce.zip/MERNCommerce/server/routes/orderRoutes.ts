import { Router } from "express";
import { createOrder, getOrderById, getUserOrders, getAllOrders, updateOrderToPaid } from "../controllers/orderController";
import { protect, admin } from "../middleware/auth";

const router = Router();

router.use(protect);

router.post("/", createOrder);
router.get("/", getUserOrders);
router.get("/all", admin, getAllOrders);
router.get("/:id", getOrderById);
router.put("/:id/pay", updateOrderToPaid);

export default router;
