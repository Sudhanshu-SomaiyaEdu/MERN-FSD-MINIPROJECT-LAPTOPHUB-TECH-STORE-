import { Router } from "express";
import { createProduct, updateProduct, deleteProduct } from "../controllers/adminController";
import { protect, admin } from "../middleware/auth";

const router = Router();

router.use(protect);
router.use(admin);

router.post("/products", createProduct);
router.put("/products/:id", updateProduct);
router.delete("/products/:id", deleteProduct);

export default router;
