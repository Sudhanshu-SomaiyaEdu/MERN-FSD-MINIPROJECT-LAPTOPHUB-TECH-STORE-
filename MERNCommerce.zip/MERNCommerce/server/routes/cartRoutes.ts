import { Router } from "express";
import { getCartItems, addCartItem, updateCartItem, removeCartItem, clearCart } from "../controllers/cartController";
import { protect } from "../middleware/auth";

const router = Router();

router.use(protect);

router.get("/", getCartItems);
router.post("/", addCartItem);
router.put("/:id", updateCartItem);
router.delete("/:id", removeCartItem);
router.delete("/", clearCart);

export default router;
