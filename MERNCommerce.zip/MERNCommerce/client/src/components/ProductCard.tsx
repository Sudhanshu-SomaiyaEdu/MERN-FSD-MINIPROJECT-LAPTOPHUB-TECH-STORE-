import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Star, ShoppingCart } from "lucide-react";
import { Link } from "wouter";

interface ProductCardProps {
  id: string;
  name: string;
  image: string;
  brand: string;
  price: number;
  originalPrice?: number;
  rating?: number;
  reviewCount?: number;
  processor?: string;
  ram?: string;
  storage?: string;
  inStock?: boolean;
}

export function ProductCard({
  id,
  name,
  image,
  brand,
  price,
  originalPrice,
  rating = 0,
  reviewCount = 0,
  processor,
  ram,
  storage,
  inStock = true,
}: ProductCardProps) {
  const discount = originalPrice ? Math.round(((originalPrice - price) / originalPrice) * 100) : 0;

  return (
    <Card className="hover-elevate overflow-hidden group" data-testid={`card-product-${id}`}>
      <Link href={`/product/${id}`}>
        <a>
          <div className="aspect-square bg-muted overflow-hidden">
            <img
              src={image}
              alt={name}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              data-testid={`img-product-${id}`}
            />
          </div>
        </a>
      </Link>
      
      <CardContent className="p-4 space-y-2">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            <p className="text-xs text-muted-foreground font-medium mb-1">{brand}</p>
            <Link href={`/product/${id}`}>
              <a>
                <h3 className="font-semibold line-clamp-2 hover:text-primary transition-colors" data-testid={`text-product-name-${id}`}>
                  {name}
                </h3>
              </a>
            </Link>
          </div>
          {discount > 0 && (
            <Badge variant="destructive" className="shrink-0">-{discount}%</Badge>
          )}
        </div>

        {(processor || ram || storage) && (
          <p className="text-xs text-muted-foreground line-clamp-1">
            {[processor, ram, storage].filter(Boolean).join(" • ")}
          </p>
        )}

        {rating > 0 && (
          <div className="flex items-center gap-1">
            <div className="flex items-center">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`h-3 w-3 ${i < rating ? "fill-primary text-primary" : "fill-muted text-muted"}`}
                />
              ))}
            </div>
            <span className="text-xs text-muted-foreground">({reviewCount})</span>
          </div>
        )}

        <div className="flex items-baseline gap-2">
          <p className="text-2xl font-bold font-heading" data-testid={`text-price-${id}`}>
            ${price.toLocaleString()}
          </p>
          {originalPrice && (
            <p className="text-sm text-muted-foreground line-through">
              ${originalPrice.toLocaleString()}
            </p>
          )}
        </div>
      </CardContent>

      <CardFooter className="p-4 pt-0">
        <Button 
          className="w-full" 
          disabled={!inStock}
          data-testid={`button-add-to-cart-${id}`}
          onClick={(e) => {
            e.preventDefault();
            console.log(`Added product ${id} to cart`);
          }}
        >
          <ShoppingCart className="h-4 w-4 mr-2" />
          {inStock ? "Add to Cart" : "Out of Stock"}
        </Button>
      </CardFooter>
    </Card>
  );
}
