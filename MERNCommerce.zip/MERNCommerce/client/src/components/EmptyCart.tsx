import { ShoppingCart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export function EmptyCart() {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-4" data-testid="empty-cart">
      <div className="rounded-full bg-muted p-6 mb-6">
        <ShoppingCart className="h-16 w-16 text-muted-foreground" />
      </div>
      <h2 className="font-heading text-2xl font-bold mb-2">Your cart is empty</h2>
      <p className="text-muted-foreground mb-8 text-center max-w-md">
        Looks like you haven't added anything to your cart yet. Start shopping to find your perfect laptop!
      </p>
      <Link href="/products">
        <a>
          <Button size="lg" data-testid="button-continue-shopping">
            Continue Shopping
          </Button>
        </a>
      </Link>
    </div>
  );
}
