import { Link } from "wouter";
import { SiVisa, SiMastercard, SiAmericanexpress } from "react-icons/si";

export function Footer() {
  return (
    <footer className="border-t bg-card mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="font-heading text-lg font-bold mb-4">LaptopHub</div>
            <p className="text-sm text-muted-foreground">
              Your trusted source for premium laptops. Quality products, expert support, fast shipping.
            </p>
          </div>
          
          <div>
            <h3 className="font-semibold mb-4">Shop</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/products">
                  <a className="text-muted-foreground hover:text-foreground" data-testid="link-footer-products">All Products</a>
                </Link>
              </li>
              <li>
                <Link href="/gaming">
                  <a className="text-muted-foreground hover:text-foreground" data-testid="link-footer-gaming">Gaming Laptops</a>
                </Link>
              </li>
              <li>
                <Link href="/business">
                  <a className="text-muted-foreground hover:text-foreground" data-testid="link-footer-business">Business Laptops</a>
                </Link>
              </li>
              <li>
                <Link href="/deals">
                  <a className="text-muted-foreground hover:text-foreground" data-testid="link-footer-deals">Special Deals</a>
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Support</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/contact">
                  <a className="text-muted-foreground hover:text-foreground" data-testid="link-footer-contact">Contact Us</a>
                </Link>
              </li>
              <li>
                <Link href="/shipping">
                  <a className="text-muted-foreground hover:text-foreground" data-testid="link-footer-shipping">Shipping Info</a>
                </Link>
              </li>
              <li>
                <Link href="/returns">
                  <a className="text-muted-foreground hover:text-foreground" data-testid="link-footer-returns">Returns</a>
                </Link>
              </li>
              <li>
                <Link href="/faq">
                  <a className="text-muted-foreground hover:text-foreground" data-testid="link-footer-faq">FAQ</a>
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Company</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/about">
                  <a className="text-muted-foreground hover:text-foreground" data-testid="link-footer-about">About Us</a>
                </Link>
              </li>
              <li>
                <Link href="/privacy">
                  <a className="text-muted-foreground hover:text-foreground" data-testid="link-footer-privacy">Privacy Policy</a>
                </Link>
              </li>
              <li>
                <Link href="/terms">
                  <a className="text-muted-foreground hover:text-foreground" data-testid="link-footer-terms">Terms of Service</a>
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t mt-8 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-muted-foreground">
            © 2024 LaptopHub. All rights reserved.
          </p>
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted-foreground">Secure Payment:</span>
            <div className="flex items-center gap-2">
              <SiVisa className="h-8 w-auto text-muted-foreground" />
              <SiMastercard className="h-8 w-auto text-muted-foreground" />
              <SiAmericanexpress className="h-8 w-auto text-muted-foreground" />
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
