import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import { Link } from "wouter";

interface HeroProps {
  image: string;
  title: string;
  subtitle: string;
  ctaText?: string;
  ctaLink?: string;
}

export function Hero({ 
  image, 
  title, 
  subtitle, 
  ctaText = "Shop Now", 
  ctaLink = "/products" 
}: HeroProps) {
  return (
    <div className="relative h-[80vh] min-h-[500px] overflow-hidden">
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${image})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-black/50" />
      </div>
      
      <div className="relative h-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col justify-center h-full max-w-2xl">
          <h1 className="font-heading text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6" data-testid="text-hero-title">
            {title}
          </h1>
          <p className="text-lg sm:text-xl text-white/90 mb-8" data-testid="text-hero-subtitle">
            {subtitle}
          </p>
          <div className="flex flex-wrap gap-4">
            <Link href={ctaLink}>
              <a>
                <Button 
                  size="lg" 
                  className="bg-primary/90 backdrop-blur-sm hover:bg-primary"
                  data-testid="button-hero-cta"
                >
                  {ctaText}
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </a>
            </Link>
            <Link href="/deals">
              <a>
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="bg-white/10 backdrop-blur-sm border-white/30 text-white hover:bg-white/20"
                  data-testid="button-hero-secondary"
                >
                  View Deals
                </Button>
              </a>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
