import { ShoppingCart, User, Search, Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { Link } from "wouter";

interface HeaderProps {
  cartItemCount?: number;
  isLoggedIn?: boolean;
  userName?: string;
  isAdmin?: boolean;
}

export function Header({ cartItemCount = 0, isLoggedIn = false, userName, isAdmin = false }: HeaderProps) {
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between gap-4">
          <div className="flex items-center gap-6">
            <Button variant="ghost" size="icon" className="lg:hidden" data-testid="button-menu">
              <Menu className="h-5 w-5" />
            </Button>
            <Link href="/">
              <a className="flex items-center gap-2" data-testid="link-home">
                <div className="font-heading text-xl font-bold">LaptopHub</div>
              </a>
            </Link>
            <nav className="hidden lg:flex items-center gap-1">
              <Link href="/products">
                <a>
                  <Button variant="ghost" data-testid="link-products">Products</Button>
                </a>
              </Link>
              <Link href="/gaming">
                <a>
                  <Button variant="ghost" data-testid="link-gaming">Gaming</Button>
                </a>
              </Link>
              <Link href="/business">
                <a>
                  <Button variant="ghost" data-testid="link-business">Business</Button>
                </a>
              </Link>
              <Link href="/deals">
                <a>
                  <Button variant="ghost" data-testid="link-deals">Deals</Button>
                </a>
              </Link>
            </nav>
          </div>

          <div className="flex-1 max-w-md hidden md:block">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search laptops..."
                className="pl-9"
                data-testid="input-search"
              />
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Link href="/cart">
              <a>
                <Button variant="ghost" size="icon" className="relative" data-testid="button-cart">
                  <ShoppingCart className="h-5 w-5" />
                  {cartItemCount > 0 && (
                    <Badge
                      variant="destructive"
                      className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs"
                      data-testid="badge-cart-count"
                    >
                      {cartItemCount}
                    </Badge>
                  )}
                </Button>
              </a>
            </Link>

            {isLoggedIn ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" data-testid="button-user-menu">
                    <User className="h-5 w-5" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <div className="px-2 py-1.5">
                    <p className="text-sm font-medium" data-testid="text-username">{userName || "User"}</p>
                  </div>
                  <DropdownMenuSeparator />
                  <Link href="/profile">
                    <a>
                      <DropdownMenuItem data-testid="link-profile">Profile</DropdownMenuItem>
                    </a>
                  </Link>
                  <Link href="/orders">
                    <a>
                      <DropdownMenuItem data-testid="link-orders">My Orders</DropdownMenuItem>
                    </a>
                  </Link>
                  {isAdmin && (
                    <>
                      <DropdownMenuSeparator />
                      <Link href="/admin">
                        <a>
                          <DropdownMenuItem data-testid="link-admin">Admin Dashboard</DropdownMenuItem>
                        </a>
                      </Link>
                    </>
                  )}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem data-testid="button-logout">Logout</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Link href="/login">
                <a>
                  <Button variant="ghost" data-testid="button-login">Sign In</Button>
                </a>
              </Link>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
