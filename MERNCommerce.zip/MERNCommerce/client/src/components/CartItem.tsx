import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Minus, Plus, X } from "lucide-react";
import { Link } from "wouter";
import { useState } from "react";

interface CartItemProps {
  id: string;
  name: string;
  image: string;
  brand: string;
  price: number;
  quantity: number;
  processor?: string;
  ram?: string;
  storage?: string;
  onQuantityChange?: (id: string, quantity: number) => void;
  onRemove?: (id: string) => void;
}

export function CartItem({
  id,
  name,
  image,
  brand,
  price,
  quantity: initialQuantity,
  processor,
  ram,
  storage,
  onQuantityChange,
  onRemove,
}: CartItemProps) {
  const [quantity, setQuantity] = useState(initialQuantity);

  const handleQuantityChange = (newQuantity: number) => {
    if (newQuantity >= 1 && newQuantity <= 10) {
      setQuantity(newQuantity);
      onQuantityChange?.(id, newQuantity);
      console.log(`Updated quantity for ${id} to ${newQuantity}`);
    }
  };

  const handleRemove = () => {
    onRemove?.(id);
    console.log(`Removed item ${id} from cart`);
  };

  return (
    <Card data-testid={`card-cart-item-${id}`}>
      <CardContent className="p-4">
        <div className="flex gap-4">
          <Link href={`/product/${id}`}>
            <a>
              <div className="w-24 h-24 bg-muted rounded-md overflow-hidden shrink-0">
                <img
                  src={image}
                  alt={name}
                  className="w-full h-full object-cover"
                  data-testid={`img-cart-item-${id}`}
                />
              </div>
            </a>
          </Link>

          <div className="flex-1 min-w-0">
            <div className="flex justify-between gap-4">
              <div className="flex-1 min-w-0">
                <p className="text-xs text-muted-foreground mb-1">{brand}</p>
                <Link href={`/product/${id}`}>
                  <a>
                    <h3 className="font-semibold line-clamp-2 hover:text-primary transition-colors" data-testid={`text-cart-item-name-${id}`}>
                      {name}
                    </h3>
                  </a>
                </Link>
                {(processor || ram || storage) && (
                  <p className="text-xs text-muted-foreground mt-1">
                    {[processor, ram, storage].filter(Boolean).join(" • ")}
                  </p>
                )}
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={handleRemove}
                data-testid={`button-remove-${id}`}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>

            <div className="flex items-center justify-between mt-4">
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => handleQuantityChange(quantity - 1)}
                  disabled={quantity <= 1}
                  data-testid={`button-decrease-${id}`}
                >
                  <Minus className="h-3 w-3" />
                </Button>
                <Input
                  type="number"
                  value={quantity}
                  onChange={(e) => handleQuantityChange(parseInt(e.target.value) || 1)}
                  className="w-16 text-center"
                  min="1"
                  max="10"
                  data-testid={`input-quantity-${id}`}
                />
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => handleQuantityChange(quantity + 1)}
                  disabled={quantity >= 10}
                  data-testid={`button-increase-${id}`}
                >
                  <Plus className="h-3 w-3" />
                </Button>
              </div>
              <p className="text-lg font-bold font-heading" data-testid={`text-item-total-${id}`}>
                ${(price * quantity).toLocaleString()}
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
