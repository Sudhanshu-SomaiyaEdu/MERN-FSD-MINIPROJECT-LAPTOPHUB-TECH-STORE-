import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { CreditCard } from "lucide-react";

interface PaymentFormProps {
  onSubmit?: (data: any) => void;
}

export function PaymentForm({ onSubmit }: PaymentFormProps) {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const formData = new FormData(e.target as HTMLFormElement);
    const data = Object.fromEntries(formData);
    onSubmit?.(data);
    console.log("Payment form submitted:", data);
  };

  return (
    <Card data-testid="card-payment-form">
      <CardHeader>
        <CardTitle className="font-heading">Payment Method</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <RadioGroup defaultValue="stripe" name="paymentMethod">
            <div className="flex items-center space-x-2 p-4 border rounded-md hover-elevate">
              <RadioGroupItem value="stripe" id="stripe" data-testid="radio-stripe" />
              <Label htmlFor="stripe" className="flex-1 cursor-pointer flex items-center gap-2">
                <CreditCard className="h-4 w-4" />
                Credit/Debit Card (Stripe)
              </Label>
            </div>
          </RadioGroup>

          <div className="space-y-4 p-4 border rounded-md bg-muted/30">
            <p className="text-sm text-muted-foreground">
              You will be redirected to Stripe's secure checkout to complete your payment.
            </p>
            
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <CreditCard className="h-4 w-4" />
              <span>Secure payment processing by Stripe</span>
            </div>
          </div>

          <Button type="submit" className="w-full" size="lg" data-testid="button-submit-payment">
            Review Order
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
