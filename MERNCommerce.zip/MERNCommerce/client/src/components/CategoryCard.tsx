import { Card, CardContent } from "@/components/ui/card";
import { LucideIcon } from "lucide-react";
import { Link } from "wouter";

interface CategoryCardProps {
  title: string;
  description: string;
  icon: LucideIcon;
  link: string;
  color?: string;
}

export function CategoryCard({ title, description, icon: Icon, link, color = "primary" }: CategoryCardProps) {
  return (
    <Link href={link}>
      <a>
        <Card className="hover-elevate active-elevate-2 h-full" data-testid={`card-category-${title.toLowerCase().replace(/\s+/g, '-')}`}>
          <CardContent className="p-6 space-y-4">
            <div className={`inline-flex p-3 rounded-md bg-${color}/10`}>
              <Icon className={`h-6 w-6 text-${color}`} />
            </div>
            <div>
              <h3 className="font-heading text-xl font-semibold mb-2" data-testid="text-category-title">
                {title}
              </h3>
              <p className="text-sm text-muted-foreground" data-testid="text-category-description">
                {description}
              </p>
            </div>
          </CardContent>
        </Card>
      </a>
    </Link>
  );
}
