import { AdminProductTable } from "../AdminProductTable";

export default function AdminProductTableExample() {
  const mockProducts = [
    { id: "1", name: "Gaming Laptop Pro X15", brand: "TechPro", category: "Gaming", price: 1299, stock: 15 },
    { id: "2", name: "Business Ultrabook Elite", brand: "WorkStation", category: "Business", price: 899, stock: 8 },
    { id: "3", name: "Creator Workstation Max", brand: "ProBook", category: "Workstation", price: 2199, stock: 5 },
  ];

  return (
    <div className="max-w-5xl">
      <AdminProductTable
        products={mockProducts}
        onEdit={(id) => console.log("Edit:", id)}
        onDelete={(id) => console.log("Delete:", id)}
      />
    </div>
  );
}
