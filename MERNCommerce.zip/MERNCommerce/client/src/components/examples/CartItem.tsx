import { CartItem } from "../CartItem";
import gamingLaptop from "@assets/generated_images/Gaming_laptop_product_shot_413042a2.png";

export default function CartItemExample() {
  return (
    <div className="max-w-2xl">
      <CartItem
        id="1"
        name="Gaming Laptop Pro X15 - High Performance RGB Keyboard"
        image={gamingLaptop}
        brand="TechPro"
        price={1299}
        quantity={2}
        processor="Intel i7"
        ram="16GB"
        storage="512GB SSD"
        onQuantityChange={(id, qty) => console.log(`Quantity changed: ${id} -> ${qty}`)}
        onRemove={(id) => console.log(`Removed: ${id}`)}
      />
    </div>
  );
}
