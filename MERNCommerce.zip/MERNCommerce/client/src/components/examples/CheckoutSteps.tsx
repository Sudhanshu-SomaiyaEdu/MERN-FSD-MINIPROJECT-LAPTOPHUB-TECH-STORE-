import { CheckoutSteps } from "../CheckoutSteps";

export default function CheckoutStepsExample() {
  return (
    <div className="max-w-2xl mx-auto">
      <CheckoutSteps currentStep={2} />
    </div>
  );
}
