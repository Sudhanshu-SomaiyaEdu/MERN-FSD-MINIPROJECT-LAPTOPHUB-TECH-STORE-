import { OrderSummary } from "../OrderSummary";

export default function OrderSummaryExample() {
  return (
    <div className="max-w-sm">
      <OrderSummary
        subtotal={2598}
        shipping={0}
        tax={207}
        discount={100}
        showCheckoutButton={true}
        onCheckout={() => console.log("Checkout clicked")}
      />
    </div>
  );
}
