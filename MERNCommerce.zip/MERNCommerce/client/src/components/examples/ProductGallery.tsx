import { ProductGallery } from "../ProductGallery";
import gamingLaptop from "@assets/generated_images/Gaming_laptop_product_shot_413042a2.png";
import businessLaptop from "@assets/generated_images/Business_ultrabook_product_shot_15371343.png";
import workstationLaptop from "@assets/generated_images/Workstation_laptop_product_shot_795ba6a5.png";

export default function ProductGalleryExample() {
  return (
    <div className="max-w-2xl">
      <ProductGallery
        images={[gamingLaptop, businessLaptop, workstationLaptop]}
        productName="Gaming Laptop Pro X15"
      />
    </div>
  );
}
