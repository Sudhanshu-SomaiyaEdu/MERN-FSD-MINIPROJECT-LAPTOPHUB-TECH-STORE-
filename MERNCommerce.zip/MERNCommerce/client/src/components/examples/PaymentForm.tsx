import { PaymentForm } from "../PaymentForm";

export default function PaymentFormExample() {
  return (
    <div className="max-w-2xl">
      <PaymentForm onSubmit={(data) => console.log("Submitted:", data)} />
    </div>
  );
}
