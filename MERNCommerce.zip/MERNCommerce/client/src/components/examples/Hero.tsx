import { Hero } from "../Hero";
import heroImage from "@assets/generated_images/Hero_laptop_workspace_scene_bc9bc4b0.png";

export default function HeroExample() {
  return (
    <Hero
      image={heroImage}
      title="Power Your Productivity"
      subtitle="Discover premium laptops designed for professionals, gamers, and creators. Free shipping on orders over $999."
      ctaText="Shop Now"
      ctaLink="/products"
    />
  );
}
