import { CategoryCard } from "../CategoryCard";
import { Gamepad2, Briefcase, Cpu, Laptop } from "lucide-react";

export default function CategoryCardExample() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-7xl">
      <CategoryCard
        title="Gaming"
        description="High-performance laptops for gamers"
        icon={Gamepad2}
        link="/gaming"
        color="primary"
      />
      <CategoryCard
        title="Business"
        description="Professional laptops for work"
        icon={Briefcase}
        link="/business"
        color="primary"
      />
      <CategoryCard
        title="Workstation"
        description="Powerful laptops for creators"
        icon={Cpu}
        link="/workstation"
        color="primary"
      />
      <CategoryCard
        title="Ultrabooks"
        description="Lightweight and portable"
        icon={Laptop}
        link="/ultrabooks"
        color="primary"
      />
    </div>
  );
}
