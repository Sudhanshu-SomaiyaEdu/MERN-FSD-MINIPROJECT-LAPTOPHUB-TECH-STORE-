import { Header } from "../Header";

export default function HeaderExample() {
  return <Header cartItemCount={3} isLoggedIn={true} userName="John Doe" isAdmin={true} />;
}
