import { Footer } from "../Footer";

export default function FooterExample() {
  return <Footer />;
}
