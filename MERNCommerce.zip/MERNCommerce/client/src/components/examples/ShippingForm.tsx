import { ShippingForm } from "../ShippingForm";

export default function ShippingFormExample() {
  return (
    <div className="max-w-2xl">
      <ShippingForm onSubmit={(data) => console.log("Submitted:", data)} />
    </div>
  );
}
