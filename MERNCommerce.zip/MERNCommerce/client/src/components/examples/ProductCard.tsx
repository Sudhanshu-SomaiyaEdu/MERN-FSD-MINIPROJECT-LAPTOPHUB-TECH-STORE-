import { ProductCard } from "../ProductCard";
import gamingLaptop from "@assets/generated_images/Gaming_laptop_product_shot_413042a2.png";

export default function ProductCardExample() {
  return (
    <div className="max-w-sm">
      <ProductCard
        id="1"
        name="Gaming Laptop Pro X15 - High Performance RGB Keyboard"
        image={gamingLaptop}
        brand="TechPro"
        price={1299}
        originalPrice={1599}
        rating={5}
        reviewCount={142}
        processor="Intel i7"
        ram="16GB"
        storage="512GB SSD"
        inStock={true}
      />
    </div>
  );
}
