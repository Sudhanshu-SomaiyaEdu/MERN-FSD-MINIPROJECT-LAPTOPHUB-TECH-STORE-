import { ReviewCard } from "../ReviewCard";

export default function ReviewCardExample() {
  return (
    <div className="max-w-2xl space-y-4">
      <ReviewCard
        name="Sarah Johnson"
        rating={5}
        comment="Excellent laptop for gaming! The performance is outstanding and the RGB keyboard is beautiful. Highly recommend for anyone looking for a powerful gaming machine."
        date="2 days ago"
        verified={true}
      />
      <ReviewCard
        name="Mike Chen"
        rating={4}
        comment="Great build quality and fast delivery. Battery life could be better, but overall very satisfied with the purchase."
        date="1 week ago"
        verified={true}
      />
    </div>
  );
}
