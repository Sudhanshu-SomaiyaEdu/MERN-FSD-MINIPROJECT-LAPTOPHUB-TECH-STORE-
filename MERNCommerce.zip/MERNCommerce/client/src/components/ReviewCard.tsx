import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Star } from "lucide-react";

interface ReviewCardProps {
  name: string;
  rating: number;
  comment: string;
  date: string;
  verified?: boolean;
}

export function ReviewCard({ name, rating, comment, date, verified = true }: ReviewCardProps) {
  const initials = name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase();

  return (
    <Card data-testid={`card-review-${name.toLowerCase().replace(/\s+/g, '-')}`}>
      <CardContent className="p-6 space-y-4">
        <div className="flex items-start gap-4">
          <Avatar>
            <AvatarFallback>{initials}</AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <div className="flex items-center justify-between gap-2 mb-1">
              <h4 className="font-semibold" data-testid="text-reviewer-name">{name}</h4>
              {verified && (
                <span className="text-xs text-muted-foreground">Verified Purchase</span>
              )}
            </div>
            <div className="flex items-center gap-2 mb-2">
              <div className="flex items-center">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`h-3 w-3 ${i < rating ? "fill-primary text-primary" : "fill-muted text-muted"}`}
                  />
                ))}
              </div>
              <span className="text-xs text-muted-foreground">{date}</span>
            </div>
            <p className="text-sm text-muted-foreground" data-testid="text-review-comment">
              {comment}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
