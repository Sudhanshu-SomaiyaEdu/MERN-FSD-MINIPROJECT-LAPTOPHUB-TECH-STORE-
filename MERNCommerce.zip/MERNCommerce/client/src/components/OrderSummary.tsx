import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";

interface OrderSummaryProps {
  subtotal: number;
  shipping?: number;
  tax?: number;
  discount?: number;
  showCheckoutButton?: boolean;
  onCheckout?: () => void;
}

export function OrderSummary({
  subtotal,
  shipping = 0,
  tax = 0,
  discount = 0,
  showCheckoutButton = true,
  onCheckout,
}: OrderSummaryProps) {
  const total = subtotal + shipping + tax - discount;
  const freeShippingThreshold = 999;
  const remainingForFreeShipping = freeShippingThreshold - subtotal;

  return (
    <Card className="sticky top-20" data-testid="card-order-summary">
      <CardHeader>
        <CardTitle className="font-heading">Order Summary</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {remainingForFreeShipping > 0 && remainingForFreeShipping < freeShippingThreshold && (
          <div className="bg-muted px-3 py-2 rounded-md text-sm">
            Add <span className="font-semibold">${remainingForFreeShipping}</span> more for free shipping!
          </div>
        )}

        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Subtotal</span>
            <span data-testid="text-subtotal">${subtotal.toLocaleString()}</span>
          </div>
          {discount > 0 && (
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Discount</span>
              <span className="text-destructive" data-testid="text-discount">
                -${discount.toLocaleString()}
              </span>
            </div>
          )}
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Shipping</span>
            <span data-testid="text-shipping">
              {shipping === 0 ? "FREE" : `$${shipping.toLocaleString()}`}
            </span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Tax</span>
            <span data-testid="text-tax">${tax.toLocaleString()}</span>
          </div>
        </div>

        <Separator />

        <div className="flex justify-between text-lg font-bold">
          <span>Total</span>
          <span data-testid="text-total">${total.toLocaleString()}</span>
        </div>

        {showCheckoutButton && (
          <Button 
            className="w-full" 
            size="lg"
            onClick={() => {
              onCheckout?.();
              console.log("Proceeding to checkout");
            }}
            data-testid="button-checkout"
          >
            Proceed to Checkout
          </Button>
        )}

        <p className="text-xs text-muted-foreground text-center">
          Secure checkout powered by Stripe
        </p>
      </CardContent>
    </Card>
  );
}
