import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ProductGallery } from "@/components/ProductGallery";
import { ReviewCard } from "@/components/ReviewCard";
import { ProductCard } from "@/components/ProductCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Star, ShoppingCart, Truck, Shield, RotateCcw, Minus, Plus } from "lucide-react";
import { useState } from "react";
import gamingLaptop from "@assets/generated_images/Gaming_laptop_product_shot_413042a2.png";
import businessLaptop from "@assets/generated_images/Business_ultrabook_product_shot_15371343.png";
import workstationLaptop from "@assets/generated_images/Workstation_laptop_product_shot_795ba6a5.png";
import portableLaptop from "@assets/generated_images/Portable_laptop_product_shot_3e086ad4.png";

export default function ProductDetailPage() {
  const [quantity, setQuantity] = useState(1);

  const product = {
    id: "1",
    name: "Gaming Laptop Pro X15",
    brand: "TechPro",
    price: 1299,
    originalPrice: 1599,
    rating: 5,
    reviewCount: 142,
    inStock: true,
    images: [gamingLaptop, businessLaptop, workstationLaptop],
  };

  const relatedProducts = [
    {
      id: "2",
      name: "Business Ultrabook Elite",
      image: businessLaptop,
      brand: "WorkStation",
      price: 899,
      rating: 4,
      reviewCount: 89,
      processor: "Intel i5",
      ram: "8GB",
      storage: "256GB SSD",
    },
    {
      id: "4",
      name: "Portable Laptop Rose",
      image: portableLaptop,
      brand: "SlimTech",
      price: 749,
      rating: 4,
      reviewCount: 124,
      processor: "Intel i5",
      ram: "8GB",
      storage: "256GB SSD",
    },
    {
      id: "3",
      name: "Creator Workstation Max",
      image: workstationLaptop,
      brand: "ProBook",
      price: 2199,
      rating: 5,
      reviewCount: 67,
      processor: "Intel i9",
      ram: "32GB",
      storage: "1TB SSD",
    },
  ];

  const discount = product.originalPrice ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100) : 0;

  return (
    <div className="min-h-screen flex flex-col">
      <Header cartItemCount={2} isLoggedIn={true} userName="John Doe" />
      
      <main className="flex-1">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
            <ProductGallery images={product.images} productName={product.name} />

            <div className="space-y-6">
              <div>
                <p className="text-sm text-muted-foreground mb-2">{product.brand}</p>
                <h1 className="font-heading text-3xl font-bold mb-4" data-testid="text-product-name">
                  {product.name}
                </h1>
                <div className="flex items-center gap-3 mb-4">
                  <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`h-4 w-4 ${i < product.rating ? "fill-primary text-primary" : "fill-muted text-muted"}`}
                      />
                    ))}
                  </div>
                  <span className="text-sm text-muted-foreground">
                    {product.reviewCount} reviews
                  </span>
                </div>
                <div className="flex items-baseline gap-3 mb-4">
                  <p className="font-heading text-4xl font-bold" data-testid="text-price">
                    ${product.price.toLocaleString()}
                  </p>
                  {product.originalPrice && (
                    <>
                      <p className="text-xl text-muted-foreground line-through">
                        ${product.originalPrice.toLocaleString()}
                      </p>
                      <Badge variant="destructive">Save {discount}%</Badge>
                    </>
                  )}
                </div>
                <Badge variant={product.inStock ? "secondary" : "destructive"}>
                  {product.inStock ? "In Stock" : "Out of Stock"}
                </Badge>
              </div>

              <Separator />

              <div className="space-y-4">
                <h3 className="font-semibold">Key Features</h3>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <span className="text-primary mt-1">•</span>
                    <span>Intel Core i7-12700H Processor (12th Gen)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary mt-1">•</span>
                    <span>NVIDIA GeForce RTX 3060 Graphics Card</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary mt-1">•</span>
                    <span>16GB DDR4 RAM, expandable to 32GB</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary mt-1">•</span>
                    <span>512GB NVMe SSD Storage</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary mt-1">•</span>
                    <span>15.6" Full HD 144Hz Display</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary mt-1">•</span>
                    <span>RGB Backlit Keyboard</span>
                  </li>
                </ul>
              </div>

              <Separator />

              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <label className="font-semibold">Quantity:</label>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      data-testid="button-decrease-quantity"
                    >
                      <Minus className="h-4 w-4" />
                    </Button>
                    <Input
                      type="number"
                      value={quantity}
                      onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                      className="w-20 text-center"
                      min="1"
                      data-testid="input-quantity"
                    />
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => setQuantity(quantity + 1)}
                      data-testid="button-increase-quantity"
                    >
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <div className="flex gap-3">
                  <Button 
                    size="lg" 
                    className="flex-1"
                    onClick={() => console.log(`Added ${quantity} item(s) to cart`)}
                    data-testid="button-add-to-cart"
                  >
                    <ShoppingCart className="h-5 w-5 mr-2" />
                    Add to Cart
                  </Button>
                  <Button 
                    size="lg" 
                    variant="outline"
                    onClick={() => console.log("Buy now clicked")}
                    data-testid="button-buy-now"
                  >
                    Buy Now
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4 pt-4">
                <div className="text-center space-y-2">
                  <Truck className="h-6 w-6 mx-auto text-muted-foreground" />
                  <p className="text-xs text-muted-foreground">Free Shipping</p>
                </div>
                <div className="text-center space-y-2">
                  <Shield className="h-6 w-6 mx-auto text-muted-foreground" />
                  <p className="text-xs text-muted-foreground">1 Year Warranty</p>
                </div>
                <div className="text-center space-y-2">
                  <RotateCcw className="h-6 w-6 mx-auto text-muted-foreground" />
                  <p className="text-xs text-muted-foreground">30-Day Returns</p>
                </div>
              </div>
            </div>
          </div>

          <Tabs defaultValue="specs" className="mb-16">
            <TabsList className="grid w-full max-w-md grid-cols-3">
              <TabsTrigger value="specs" data-testid="tab-specs">Specifications</TabsTrigger>
              <TabsTrigger value="reviews" data-testid="tab-reviews">Reviews</TabsTrigger>
              <TabsTrigger value="shipping" data-testid="tab-shipping">Shipping</TabsTrigger>
            </TabsList>
            <TabsContent value="specs" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <h4 className="font-semibold">Processor</h4>
                  <p className="text-sm text-muted-foreground">Intel Core i7-12700H (12th Gen)</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-semibold">Graphics</h4>
                  <p className="text-sm text-muted-foreground">NVIDIA GeForce RTX 3060 6GB</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-semibold">Memory</h4>
                  <p className="text-sm text-muted-foreground">16GB DDR4 3200MHz</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-semibold">Storage</h4>
                  <p className="text-sm text-muted-foreground">512GB NVMe SSD</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-semibold">Display</h4>
                  <p className="text-sm text-muted-foreground">15.6" FHD 144Hz IPS</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-semibold">Battery</h4>
                  <p className="text-sm text-muted-foreground">53.5Wh, up to 6 hours</p>
                </div>
              </div>
            </TabsContent>
            <TabsContent value="reviews" className="mt-6 space-y-4">
              <ReviewCard
                name="Sarah Johnson"
                rating={5}
                comment="Excellent laptop for gaming! The performance is outstanding and the RGB keyboard is beautiful. Highly recommend for anyone looking for a powerful gaming machine."
                date="2 days ago"
                verified={true}
              />
              <ReviewCard
                name="Mike Chen"
                rating={4}
                comment="Great build quality and fast delivery. Battery life could be better, but overall very satisfied with the purchase."
                date="1 week ago"
                verified={true}
              />
            </TabsContent>
            <TabsContent value="shipping" className="mt-6">
              <div className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  Free standard shipping on all orders over $999. Orders are processed within 1-2 business days.
                </p>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>• Standard Shipping: 5-7 business days</li>
                  <li>• Express Shipping: 2-3 business days ($29.99)</li>
                  <li>• Next Day Delivery: Available in select areas ($49.99)</li>
                </ul>
              </div>
            </TabsContent>
          </Tabs>

          <div>
            <h2 className="font-heading text-2xl font-bold mb-6">You May Also Like</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {relatedProducts.map((product) => (
                <ProductCard key={product.id} {...product} />
              ))}
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
