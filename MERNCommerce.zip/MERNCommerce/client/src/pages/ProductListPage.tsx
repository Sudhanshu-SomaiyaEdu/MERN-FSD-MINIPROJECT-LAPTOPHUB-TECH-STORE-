import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ProductCard } from "@/components/ProductCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Checkbox } from "@/components/ui/checkbox";
import { SlidersHorizontal } from "lucide-react";
import { useState } from "react";
import gamingLaptop from "@assets/generated_images/Gaming_laptop_product_shot_413042a2.png";
import businessLaptop from "@assets/generated_images/Business_ultrabook_product_shot_15371343.png";
import workstationLaptop from "@assets/generated_images/Workstation_laptop_product_shot_795ba6a5.png";
import portableLaptop from "@assets/generated_images/Portable_laptop_product_shot_3e086ad4.png";
import convertibleLaptop from "@assets/generated_images/Convertible_laptop_product_shot_c7aaeac1.png";

export default function ProductListPage() {
  const [priceRange, setPriceRange] = useState([0, 3000]);
  const [showFilters, setShowFilters] = useState(false);

  const products = [
    {
      id: "1",
      name: "Gaming Laptop Pro X15",
      image: gamingLaptop,
      brand: "TechPro",
      price: 1299,
      originalPrice: 1599,
      rating: 5,
      reviewCount: 142,
      processor: "Intel i7",
      ram: "16GB",
      storage: "512GB SSD",
    },
    {
      id: "2",
      name: "Business Ultrabook Elite",
      image: businessLaptop,
      brand: "WorkStation",
      price: 899,
      rating: 4,
      reviewCount: 89,
      processor: "Intel i5",
      ram: "8GB",
      storage: "256GB SSD",
    },
    {
      id: "3",
      name: "Creator Workstation Max",
      image: workstationLaptop,
      brand: "ProBook",
      price: 2199,
      originalPrice: 2499,
      rating: 5,
      reviewCount: 67,
      processor: "Intel i9",
      ram: "32GB",
      storage: "1TB SSD",
    },
    {
      id: "4",
      name: "Portable Laptop Rose",
      image: portableLaptop,
      brand: "SlimTech",
      price: 749,
      rating: 4,
      reviewCount: 124,
      processor: "Intel i5",
      ram: "8GB",
      storage: "256GB SSD",
    },
    {
      id: "5",
      name: "Convertible 2-in-1 Pro",
      image: convertibleLaptop,
      brand: "FlexBook",
      price: 1099,
      rating: 4,
      reviewCount: 98,
      processor: "Intel i7",
      ram: "16GB",
      storage: "512GB SSD",
    },
    {
      id: "6",
      name: "Gaming Beast RTX",
      image: gamingLaptop,
      brand: "TechPro",
      price: 1799,
      rating: 5,
      reviewCount: 203,
      processor: "Intel i9",
      ram: "32GB",
      storage: "1TB SSD",
    },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Header cartItemCount={0} isLoggedIn={false} />
      
      <main className="flex-1">
        <div className="border-b bg-muted/30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <h1 className="font-heading text-4xl font-bold mb-2">All Laptops</h1>
            <p className="text-muted-foreground">Browse our complete collection of premium laptops</p>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex gap-8">
            <aside className={`w-64 shrink-0 space-y-6 ${showFilters ? "block" : "hidden lg:block"}`}>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-heading font-semibold">Filters</h3>
                  <Button variant="ghost" size="sm" data-testid="button-clear-filters">
                    Clear All
                  </Button>
                </div>

                <div className="space-y-4">
                  <div>
                    <Label className="mb-3 block">Price Range</Label>
                    <Slider
                      min={0}
                      max={3000}
                      step={100}
                      value={priceRange}
                      onValueChange={setPriceRange}
                      className="mb-2"
                      data-testid="slider-price-range"
                    />
                    <div className="flex justify-between text-sm text-muted-foreground">
                      <span>${priceRange[0]}</span>
                      <span>${priceRange[1]}</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label className="mb-3 block">Brand</Label>
                    <div className="space-y-2">
                      {["TechPro", "WorkStation", "ProBook", "SlimTech", "FlexBook"].map((brand) => (
                        <div key={brand} className="flex items-center space-x-2">
                          <Checkbox id={brand} data-testid={`checkbox-brand-${brand.toLowerCase()}`} />
                          <label
                            htmlFor={brand}
                            className="text-sm cursor-pointer"
                          >
                            {brand}
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label className="mb-3 block">Processor</Label>
                    <div className="space-y-2">
                      {["Intel i5", "Intel i7", "Intel i9"].map((processor) => (
                        <div key={processor} className="flex items-center space-x-2">
                          <Checkbox id={processor} data-testid={`checkbox-processor-${processor.toLowerCase().replace(/\s+/g, '-')}`} />
                          <label
                            htmlFor={processor}
                            className="text-sm cursor-pointer"
                          >
                            {processor}
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label className="mb-3 block">RAM</Label>
                    <div className="space-y-2">
                      {["8GB", "16GB", "32GB"].map((ram) => (
                        <div key={ram} className="flex items-center space-x-2">
                          <Checkbox id={ram} data-testid={`checkbox-ram-${ram.toLowerCase()}`} />
                          <label
                            htmlFor={ram}
                            className="text-sm cursor-pointer"
                          >
                            {ram}
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </aside>

            <div className="flex-1 min-w-0">
              <div className="flex justify-between items-center mb-6">
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="lg:hidden"
                    onClick={() => setShowFilters(!showFilters)}
                    data-testid="button-toggle-filters"
                  >
                    <SlidersHorizontal className="h-4 w-4 mr-2" />
                    Filters
                  </Button>
                  <p className="text-sm text-muted-foreground">
                    Showing {products.length} products
                  </p>
                </div>
                <Select defaultValue="featured">
                  <SelectTrigger className="w-48" data-testid="select-sort">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="featured">Featured</SelectItem>
                    <SelectItem value="price-low">Price: Low to High</SelectItem>
                    <SelectItem value="price-high">Price: High to Low</SelectItem>
                    <SelectItem value="rating">Highest Rated</SelectItem>
                    <SelectItem value="newest">Newest</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {products.map((product) => (
                  <ProductCard key={product.id} {...product} />
                ))}
              </div>

              <div className="mt-12 flex justify-center">
                <div className="flex gap-2">
                  <Button variant="outline" data-testid="button-prev-page">Previous</Button>
                  <Button variant="outline" data-testid="button-page-1">1</Button>
                  <Button data-testid="button-page-2">2</Button>
                  <Button variant="outline" data-testid="button-page-3">3</Button>
                  <Button variant="outline" data-testid="button-next-page">Next</Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
