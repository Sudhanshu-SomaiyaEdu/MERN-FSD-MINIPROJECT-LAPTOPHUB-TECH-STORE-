import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { CheckoutSteps } from "@/components/CheckoutSteps";
import { ShippingForm } from "@/components/ShippingForm";
import { PaymentForm } from "@/components/PaymentForm";
import { OrderSummary } from "@/components/OrderSummary";
import { useState } from "react";

export default function CheckoutPage() {
  const [currentStep, setCurrentStep] = useState(1);

  const handleShippingSubmit = (data: any) => {
    console.log("Shipping data:", data);
    setCurrentStep(2);
  };

  const handlePaymentSubmit = (data: any) => {
    console.log("Payment data:", data);
    setCurrentStep(3);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header cartItemCount={2} isLoggedIn={true} userName="John Doe" />
      
      <main className="flex-1 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <h1 className="font-heading text-4xl font-bold text-center mb-8">Checkout</h1>
          
          <CheckoutSteps currentStep={currentStep} />

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mt-8">
            <div className="lg:col-span-2">
              {currentStep === 1 && (
                <ShippingForm onSubmit={handleShippingSubmit} />
              )}
              {currentStep === 2 && (
                <PaymentForm onSubmit={handlePaymentSubmit} />
              )}
              {currentStep === 3 && (
                <div className="text-center py-16">
                  <div className="inline-flex p-6 rounded-full bg-primary/10 mb-6">
                    <svg className="h-16 w-16 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <h2 className="font-heading text-3xl font-bold mb-4">Order Complete!</h2>
                  <p className="text-muted-foreground mb-8">
                    Thank you for your purchase. Your order has been received and is being processed.
                  </p>
                </div>
              )}
            </div>

            <div>
              <OrderSummary
                subtotal={2198}
                shipping={0}
                tax={175.84}
                showCheckoutButton={false}
              />
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
