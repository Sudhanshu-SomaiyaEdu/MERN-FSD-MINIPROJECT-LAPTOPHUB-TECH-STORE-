import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { CartItem } from "@/components/CartItem";
import { OrderSummary } from "@/components/OrderSummary";
import { EmptyCart } from "@/components/EmptyCart";
import { useState } from "react";
import { useLocation } from "wouter";
import gamingLaptop from "@assets/generated_images/Gaming_laptop_product_shot_413042a2.png";
import businessLaptop from "@assets/generated_images/Business_ultrabook_product_shot_15371343.png";

export default function CartPage() {
  const [, setLocation] = useLocation();
  const [cartItems, setCartItems] = useState([
    {
      id: "1",
      name: "Gaming Laptop Pro X15",
      image: gamingLaptop,
      brand: "TechPro",
      price: 1299,
      quantity: 1,
      processor: "Intel i7",
      ram: "16GB",
      storage: "512GB SSD",
    },
    {
      id: "2",
      name: "Business Ultrabook Elite",
      image: businessLaptop,
      brand: "WorkStation",
      price: 899,
      quantity: 1,
      processor: "Intel i5",
      ram: "8GB",
      storage: "256GB SSD",
    },
  ]);

  const handleQuantityChange = (id: string, quantity: number) => {
    setCartItems(items =>
      items.map(item =>
        item.id === id ? { ...item, quantity } : item
      )
    );
  };

  const handleRemove = (id: string) => {
    setCartItems(items => items.filter(item => item.id !== id));
  };

  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const shipping = subtotal > 999 ? 0 : 29.99;
  const tax = subtotal * 0.08;

  if (cartItems.length === 0) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header cartItemCount={0} isLoggedIn={false} />
        <main className="flex-1">
          <EmptyCart />
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header cartItemCount={cartItems.length} isLoggedIn={true} userName="John Doe" />
      
      <main className="flex-1">
        <div className="border-b bg-muted/30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <h1 className="font-heading text-4xl font-bold">Shopping Cart</h1>
            <p className="text-muted-foreground mt-2">{cartItems.length} items in your cart</p>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-4">
              {cartItems.map((item) => (
                <CartItem
                  key={item.id}
                  {...item}
                  onQuantityChange={handleQuantityChange}
                  onRemove={handleRemove}
                />
              ))}
            </div>

            <div>
              <OrderSummary
                subtotal={subtotal}
                shipping={shipping}
                tax={tax}
                showCheckoutButton={true}
                onCheckout={() => setLocation("/checkout")}
              />
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
