import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { AdminProductTable } from "@/components/AdminProductTable";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Package, DollarSign, ShoppingCart, Users, Plus } from "lucide-react";

export default function AdminDashboard() {
  const products = [
    { id: "1", name: "Gaming Laptop Pro X15", brand: "TechPro", category: "Gaming", price: 1299, stock: 15 },
    { id: "2", name: "Business Ultrabook Elite", brand: "WorkStation", category: "Business", price: 899, stock: 8 },
    { id: "3", name: "Creator Workstation Max", brand: "ProBook", category: "Workstation", price: 2199, stock: 5 },
    { id: "4", name: "Portable Laptop Rose", brand: "SlimTech", category: "Ultrabook", price: 749, stock: 22 },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Header cartItemCount={0} isLoggedIn={true} userName="Admin" isAdmin={true} />
      
      <main className="flex-1 bg-muted/30">
        <div className="border-b bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <h1 className="font-heading text-4xl font-bold">Admin Dashboard</h1>
            <p className="text-muted-foreground mt-2">Manage your e-commerce platform</p>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
                <DollarSign className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold" data-testid="text-total-revenue">$45,231</div>
                <p className="text-xs text-muted-foreground">+20.1% from last month</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Orders</CardTitle>
                <ShoppingCart className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold" data-testid="text-total-orders">152</div>
                <p className="text-xs text-muted-foreground">+12.5% from last month</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Products</CardTitle>
                <Package className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold" data-testid="text-total-products">48</div>
                <p className="text-xs text-muted-foreground">4 categories</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Customers</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold" data-testid="text-total-customers">573</div>
                <p className="text-xs text-muted-foreground">+8.2% from last month</p>
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="products" className="space-y-6">
            <TabsList>
              <TabsTrigger value="products" data-testid="tab-products">Products</TabsTrigger>
              <TabsTrigger value="orders" data-testid="tab-orders">Orders</TabsTrigger>
              <TabsTrigger value="customers" data-testid="tab-customers">Customers</TabsTrigger>
            </TabsList>

            <TabsContent value="products" className="space-y-6">
              <div className="flex justify-between items-center">
                <div>
                  <h2 className="font-heading text-2xl font-bold">Products</h2>
                  <p className="text-muted-foreground">Manage your product inventory</p>
                </div>
                <Button data-testid="button-add-product">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Product
                </Button>
              </div>
              <AdminProductTable
                products={products}
                onEdit={(id) => console.log("Edit product:", id)}
                onDelete={(id) => console.log("Delete product:", id)}
              />
            </TabsContent>

            <TabsContent value="orders" className="space-y-6">
              <div className="flex justify-between items-center">
                <div>
                  <h2 className="font-heading text-2xl font-bold">Orders</h2>
                  <p className="text-muted-foreground">View and manage customer orders</p>
                </div>
              </div>
              <Card>
                <CardContent className="p-6">
                  <p className="text-muted-foreground text-center py-8">Order management interface</p>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="customers" className="space-y-6">
              <div className="flex justify-between items-center">
                <div>
                  <h2 className="font-heading text-2xl font-bold">Customers</h2>
                  <p className="text-muted-foreground">Manage customer accounts</p>
                </div>
              </div>
              <Card>
                <CardContent className="p-6">
                  <p className="text-muted-foreground text-center py-8">Customer management interface</p>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>

      <Footer />
    </div>
  );
}
