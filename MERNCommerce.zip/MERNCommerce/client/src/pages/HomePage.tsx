import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Hero } from "@/components/Hero";
import { CategoryCard } from "@/components/CategoryCard";
import { ProductCard } from "@/components/ProductCard";
import { ReviewCard } from "@/components/ReviewCard";
import { Button } from "@/components/ui/button";
import { Gamepad2, Briefcase, Cpu, Laptop, Truck, Shield, Headphones } from "lucide-react";
import { Link } from "wouter";
import heroImage from "@assets/generated_images/Hero_laptop_workspace_scene_bc9bc4b0.png";
import gamingLaptop from "@assets/generated_images/Gaming_laptop_product_shot_413042a2.png";
import businessLaptop from "@assets/generated_images/Business_ultrabook_product_shot_15371343.png";
import workstationLaptop from "@assets/generated_images/Workstation_laptop_product_shot_795ba6a5.png";
import portableLaptop from "@assets/generated_images/Portable_laptop_product_shot_3e086ad4.png";

export default function HomePage() {
  const featuredProducts = [
    {
      id: "1",
      name: "Gaming Laptop Pro X15 - High Performance",
      image: gamingLaptop,
      brand: "TechPro",
      price: 1299,
      originalPrice: 1599,
      rating: 5,
      reviewCount: 142,
      processor: "Intel i7",
      ram: "16GB",
      storage: "512GB SSD",
    },
    {
      id: "2",
      name: "Business Ultrabook Elite - Premium Build",
      image: businessLaptop,
      brand: "WorkStation",
      price: 899,
      rating: 4,
      reviewCount: 89,
      processor: "Intel i5",
      ram: "8GB",
      storage: "256GB SSD",
    },
    {
      id: "3",
      name: "Creator Workstation Max - Professional",
      image: workstationLaptop,
      brand: "ProBook",
      price: 2199,
      originalPrice: 2499,
      rating: 5,
      reviewCount: 67,
      processor: "Intel i9",
      ram: "32GB",
      storage: "1TB SSD",
    },
    {
      id: "4",
      name: "Portable Laptop Rose - Lightweight",
      image: portableLaptop,
      brand: "SlimTech",
      price: 749,
      rating: 4,
      reviewCount: 124,
      processor: "Intel i5",
      ram: "8GB",
      storage: "256GB SSD",
    },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Header cartItemCount={0} isLoggedIn={false} />
      
      <main className="flex-1">
        <Hero
          image={heroImage}
          title="Power Your Productivity"
          subtitle="Discover premium laptops designed for professionals, gamers, and creators. Free shipping on orders over $999."
        />

        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <h2 className="font-heading text-3xl font-bold text-center mb-12">Shop by Category</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <CategoryCard
              title="Gaming"
              description="High-performance laptops for gamers"
              icon={Gamepad2}
              link="/products?category=gaming"
            />
            <CategoryCard
              title="Business"
              description="Professional laptops for work"
              icon={Briefcase}
              link="/products?category=business"
            />
            <CategoryCard
              title="Workstation"
              description="Powerful laptops for creators"
              icon={Cpu}
              link="/products?category=workstation"
            />
            <CategoryCard
              title="Ultrabooks"
              description="Lightweight and portable"
              icon={Laptop}
              link="/products?category=ultrabook"
            />
          </div>
        </section>

        <section className="bg-muted/30 py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-end mb-8">
              <div>
                <h2 className="font-heading text-3xl font-bold mb-2">Featured Products</h2>
                <p className="text-muted-foreground">Handpicked laptops with the best value</p>
              </div>
              <Link href="/products">
                <a>
                  <Button variant="outline" data-testid="button-view-all">View All</Button>
                </a>
              </Link>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {featuredProducts.map((product) => (
                <ProductCard key={product.id} {...product} />
              ))}
            </div>
          </div>
        </section>

        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <h2 className="font-heading text-3xl font-bold text-center mb-12">Why Choose LaptopHub?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center space-y-4">
              <div className="inline-flex p-4 rounded-full bg-primary/10">
                <Truck className="h-8 w-8 text-primary" />
              </div>
              <h3 className="font-heading text-xl font-semibold">Free Shipping</h3>
              <p className="text-muted-foreground">
                Free shipping on all orders over $999. Fast and reliable delivery nationwide.
              </p>
            </div>
            <div className="text-center space-y-4">
              <div className="inline-flex p-4 rounded-full bg-primary/10">
                <Shield className="h-8 w-8 text-primary" />
              </div>
              <h3 className="font-heading text-xl font-semibold">Secure Payment</h3>
              <p className="text-muted-foreground">
                Your payment information is encrypted and processed securely through Stripe.
              </p>
            </div>
            <div className="text-center space-y-4">
              <div className="inline-flex p-4 rounded-full bg-primary/10">
                <Headphones className="h-8 w-8 text-primary" />
              </div>
              <h3 className="font-heading text-xl font-semibold">Expert Support</h3>
              <p className="text-muted-foreground">
                Our team of experts is here to help you find the perfect laptop for your needs.
              </p>
            </div>
          </div>
        </section>

        <section className="bg-muted/30 py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="font-heading text-3xl font-bold text-center mb-12">What Our Customers Say</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <ReviewCard
                name="Sarah Johnson"
                rating={5}
                comment="Excellent laptop for gaming! The performance is outstanding and the RGB keyboard is beautiful."
                date="2 days ago"
                verified={true}
              />
              <ReviewCard
                name="Mike Chen"
                rating={4}
                comment="Great build quality and fast delivery. Battery life could be better, but overall very satisfied."
                date="1 week ago"
                verified={true}
              />
              <ReviewCard
                name="Emily Rodriguez"
                rating={5}
                comment="Perfect for my creative work. The display is stunning and it handles rendering like a champ!"
                date="2 weeks ago"
                verified={true}
              />
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
